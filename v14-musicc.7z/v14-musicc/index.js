const configurationFilePath = require('./config.js');
const { ShardingManager } = require('discord.js');

if (configurationFilePath.shardManager.shardStatus == true) {
  const manager = new ShardingManager('./bot.js', { token: configurationFilePath.TOKEN || process.env.TOKEN });
  manager.on('shardCreate', shard => console.log(`Launched shard ${shard.id}`));
  manager.spawn();
} else {
  require("./bot.js");
}
